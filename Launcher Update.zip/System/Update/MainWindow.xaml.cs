using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
namespace HoYoLauncherUpdate;
public partial class MainWindow : Window
{
    private const string TargetFolderName = "System";
    private const string LauncherSubFolder = @"Resources\bin";
    private const string LauncherExeName = "HoYoLauncher.exe";
    private static readonly string[] LauncherBatNames = { "System.bat", "HoYoLauncher.bat" };
    private static string BaseDir => AppDomain.CurrentDomain.BaseDirectory;
    private static string TargetDir => Path.Combine(BaseDir, TargetFolderName);
    private static string InstalledLauncherExe =>
        Path.Combine(TargetDir, LauncherSubFolder, LauncherExeName);
    private const string TempExtractDirName = "launcher Update.tmp";
    private static string ExtractRoot => Path.Combine(BaseDir, TempExtractDirName);
    private const string RepoOwner = "manh00937-ui";
    private const string RepoName = "HoYo_Launcher_Mods";
    private const string LatestReleaseUrl = $"https://api.github.com/repos/{RepoOwner}/{RepoName}/releases/latest";
    private const string ReleaseListUrl = $"https://api.github.com/repos/{RepoOwner}/{RepoName}/releases?per_page=5";
    private const string TempDownloadDirName = "launcher Update.download";
    private static string DownloadDir => Path.Combine(BaseDir, TempDownloadDirName);
    private const string StarLuxeFolderName = "StarLuxe";
    private const string StarLuxeKeepDirName = "StarLuxe.UpdateKeep";
    private static string StarLuxeTargetDir => Path.Combine(TargetDir, StarLuxeFolderName);
    private string? _zipPath;
    private string? _packageDir;
    private string? _launcherExeRelativePath;
    private bool _busy;
    public MainWindow()
    {
        InitializeComponent();
        try { Environment.CurrentDirectory = BaseDir; } catch { }
        CleanupStaleBackups();
        CleanupStaleTemp();
        RestoreStaleStarLuxeKeep();
    }
    private void BrowseButton_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "Chọn file .zip bản cập nhật",
            Filter = "File zip (*.zip)|*.zip",
            CheckFileExists = true
        };
        if (dlg.ShowDialog(this) == true)
            AcceptZip(dlg.FileName);
    }
    private void Window_DragOver(object sender, DragEventArgs e)
    {
        bool ok = !IsBusy() && GetDroppedZip(e) != null;
        e.Effects = ok ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
        SetDropZoneHighlight(ok);
    }
    private void Window_DragLeave(object sender, DragEventArgs e)
    {
        SetDropZoneHighlight(false);
    }
    private void Window_Drop(object sender, DragEventArgs e)
    {
        SetDropZoneHighlight(false);
        if (IsBusy()) return;
        string? zip = GetDroppedZip(e);
        if (zip == null)
        {
            ShowError("Chỉ nhận file .zip. Hãy kéo thả file .zip của bản cập nhật vào đây.");
            return;
        }
        AcceptZip(zip);
    }
    private static string? GetDroppedZip(DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return null;
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return null;
        return files.FirstOrDefault(f =>
            File.Exists(f) &&
            string.Equals(Path.GetExtension(f), ".zip", StringComparison.OrdinalIgnoreCase));
    }
    private void AcceptZip(string zipPath)
    {
        _zipPath = zipPath;
        _packageDir = null;
        _launcherExeRelativePath = null;
        FileInfoPanel.Visibility = Visibility.Visible;
        ZipNameText.Text = Path.GetFileName(zipPath);
        try
        {
            long bytes = new FileInfo(zipPath).Length;
            ZipSizeText.Text = $"{bytes / 1024.0 / 1024.0:0.##} MB";
        }
        catch { ZipSizeText.Text = ""; }
        VerifyButton.IsEnabled = true;
        UpdateButton.Visibility = Visibility.Collapsed;
        HideStatus();
        HideSummary();
        HideError();
    }
    private async void DownloadLatestButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsBusy()) return;
        _busy = true;
        DownloadLatestButton.IsEnabled = false;
        HideSummary();
        HideError();
        try
        {
            string? zipPath = await DownloadLatestAsync();
            if (zipPath == null) return;
            AcceptZip(zipPath);
            _busy = false;
            await RunVerifyAsync();
        }
        catch (Exception ex)
        {
            ShowDownloadError("Tải bản cập nhật thất bại: " + ex.Message +
                              "\nBạn vẫn có thể kéo thả file .zip bản mới vào cửa sổ này nếu đã tải sẵn.");
        }
        finally
        {
            _busy = false;
            DownloadLatestButton.IsEnabled = true;
            ProgressB.Visibility = Visibility.Collapsed;
        }
    }
    private async Task<string?> DownloadLatestAsync()
    {
        ProgressB.Visibility = Visibility.Visible;
        ProgressB.IsIndeterminate = true;
        ProgressB.Value = 0;
        ShowStatus("Đang kiểm tra bản cập nhật mới nhất trên GitHub...");
        try
        {
            GhRelease? release = await FetchLatestReleaseAsync();
            if (release == null)
            {
                ShowDownloadError("GitHub chưa có bản phát hành (release) nào cho HoYo Launcher Mods.");
                return null;
            }
            var zips = (release.assets ?? new GhAsset[0])
                .Where(a => a != null && !string.IsNullOrEmpty(a.name) &&
                            !string.IsNullOrEmpty(a.browser_download_url) &&
                            a.name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) &&
                            a.name.IndexOf("starluxe", StringComparison.OrdinalIgnoreCase) < 0)
                .ToList();
            GhAsset? asset = zips.FirstOrDefault(a =>
                                 a.name.IndexOf("hoyo", StringComparison.OrdinalIgnoreCase) >= 0)
                             ?? zips.FirstOrDefault();
            if (asset == null)
            {
                ShowDownloadError("Release «" + ReleaseTitle(release) +
                                  "» không có file .zip của launcher để tải (gói phụ như StarLuxe đã bị bỏ qua).\n" +
                                  "Bạn hãy tải file .zip bản mới tại trang release của GitHub.");
                return null;
            }
            string latest = ExtractVersion(release.tag_name);
            if (latest.Length == 0) latest = ExtractVersion(release.name);
            string installed = InstalledLauncherVersion();
            if (latest.Length > 0 && installed.Length > 0 && !IsNewer(latest, installed))
            {
                HideStatus();
                ProgressB.Visibility = Visibility.Collapsed;
                var answer = MessageBox.Show(
                    $"Phiên bản đang cài:  {installed}\n" +
                    $"Bản mới nhất trên GitHub:  {latest}\n\n" +
                    "Bạn ĐANG dùng bản mới nhất rồi. Vẫn muốn tải lại file .zip ?",
                    "Không có Update mới", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (answer != MessageBoxResult.Yes) return null;
                ProgressB.Visibility = Visibility.Visible;
                ProgressB.IsIndeterminate = false;
                ShowStatus($"Đang tải {asset.name} từ GitHub...");
            }
            Directory.CreateDirectory(DownloadDir);
            string zipPath = Path.Combine(DownloadDir, SanitizeFileName(asset.name));
            if (File.Exists(zipPath))
            {
                try { File.Delete(zipPath); } catch {   }
            }
            ProgressB.Visibility = Visibility.Visible;
            ProgressB.IsIndeterminate = false;
            ProgressB.Value = 0;
            ShowStatus($"Đang tải {asset.name} từ GitHub...");
            long lastLoggedMb = 0;
            using (var wc = CreateWebClient())
            {
                wc.DownloadProgressChanged += (_, args) =>
                {
                    ProgressB.Value = args.ProgressPercentage;
                    long mb = args.BytesReceived / 1048576;
                    if (mb == lastLoggedMb && args.ProgressPercentage < 100) return;
                    lastLoggedMb = mb;
                    string received = (args.BytesReceived / 1048576.0).ToString("0.#");
                    string total = args.TotalBytesToReceive > 0
                        ? "/" + (args.TotalBytesToReceive / 1048576.0).ToString("0.#")
                        : "";
                    StatusText.Text = $"Đang tải từ GitHub... {received}{total} MB ({args.ProgressPercentage}%)";
                };
                await wc.DownloadFileTaskAsync(asset.browser_download_url, zipPath);
            }
            if (!File.Exists(zipPath) || new FileInfo(zipPath).Length == 0)
            {
                ShowDownloadError("Tải file thất bại (file rỗng) — kiểm tra kết nối mạng rồi thử lại.");
                return null;
            }
            HideStatus();
            return zipPath;
        }
        catch (WebException ex)
        {
            ShowDownloadError(DescribeWebError(ex));
            return null;
        }
        catch (Exception ex)
        {
            ShowDownloadError("Tải bản cập nhật thất bại: " + ex.Message);
            return null;
        }
    }
    private static async Task<GhRelease?> FetchLatestReleaseAsync()
    {
        try
        {
            var rel = FromJson<GhRelease>(await DownloadStringAsync(LatestReleaseUrl));
            if (rel != null && !rel.draft && !IsSideRelease(rel)) return rel;
        }
        catch (WebException ex) when (IsHttp404(ex))
        {
        }
        var list = FromJson<List<GhRelease>>(await DownloadStringAsync(ReleaseListUrl));
        return list?.FirstOrDefault(r => r != null && !r.draft && !IsSideRelease(r) &&
            ExtractVersion(string.IsNullOrWhiteSpace(r.tag_name) ? r.name : r.tag_name).Length > 0);
    }
    private static bool IsSideRelease(GhRelease release) =>
        (release.tag_name ?? "").IndexOf("starluxe", StringComparison.OrdinalIgnoreCase) >= 0 ||
        (release.name ?? "").IndexOf("starluxe", StringComparison.OrdinalIgnoreCase) >= 0;
    private static async Task<string> DownloadStringAsync(string url)
    {
        using var wc = CreateWebClient();
        return await wc.DownloadStringTaskAsync(url);
    }
    private static WebClient CreateWebClient()
    {
        var wc = new WebClient();
        wc.Encoding = System.Text.Encoding.UTF8;
        wc.Headers.Add(HttpRequestHeader.UserAgent, "HoYoLauncherUpdate");
        wc.Headers.Add(HttpRequestHeader.Accept, "application/vnd.github+json");
        return wc;
    }
    private static T? FromJson<T>(string json) where T : class
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json));
        return new DataContractJsonSerializer(typeof(T)).ReadObject(stream) as T;
    }
    private static bool IsHttp404(WebException ex) =>
        ex.Response is HttpWebResponse resp && resp.StatusCode == HttpStatusCode.NotFound;
    private static string DescribeWebError(WebException ex)
    {
        if (ex.Response is HttpWebResponse resp)
        {
            if (resp.StatusCode == HttpStatusCode.NotFound)
                return "Không tìm thấy file trên GitHub (lỗi 404) — release có thể đã bị xoá.";
            if (resp.StatusCode == HttpStatusCode.Forbidden)
                return "GitHub đang giới hạn số yêu cầu từ mạng của bạn (lỗi 403) — thử lại sau ít phút.";
            return $"GitHub trả lỗi {(int)resp.StatusCode} {resp.StatusDescription} — thử lại sau.";
        }
        return "Không kết nối được tới GitHub — kiểm tra kết nối mạng rồi thử lại.\n" + ex.Message;
    }
    private void ShowDownloadError(string text)
    {
        HideStatus();
        ProgressB.Visibility = Visibility.Collapsed;
        ShowError(text);
    }
    private static string ReleaseTitle(GhRelease r) =>
        !string.IsNullOrWhiteSpace(r.name) ? r.name : r.tag_name;
    private static readonly Regex VersionPattern = new Regex(@"\d+(?:\.\d+)+", RegexOptions.Compiled);
    private static string ExtractVersion(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        var m = VersionPattern.Match(text);
        return m.Success ? m.Value : "";
    }
    private static bool IsNewer(string candidate, string current)
    {
        int[] a = SplitVersion(candidate), b = SplitVersion(current);
        if (a.Length == 0 || b.Length == 0) return false;
        for (int i = 0; i < Math.Max(a.Length, b.Length); i++)
        {
            int x = i < a.Length ? a[i] : 0;
            int y = i < b.Length ? b[i] : 0;
            if (x != y) return x > y;
        }
        return false;
    }
    private static int[] SplitVersion(string v)
    {
        if (string.IsNullOrWhiteSpace(v)) return new int[0];
        string[] parts = v.Split('.');
        var nums = new int[parts.Length];
        for (int i = 0; i < parts.Length; i++)
            nums[i] = int.TryParse(parts[i], out int n) ? n : 0;
        return nums;
    }
    private static string InstalledLauncherVersion()
    {
        try
        {
            string label = ReadVersionLabelFromDevSettings();
            if (label.Length > 0) return label;
        }
        catch { }
        try
        {
            string exe = InstalledLauncherExe;
            return File.Exists(exe)
                ? ExtractVersion(FileVersionInfo.GetVersionInfo(exe).FileVersion)
                : "";
        }
        catch { return ""; }
    }
    private const string DevSettingsFileName = "devsettings.json";
    private const string DevSettingsProjectMarker = "HoYoLauncher.csproj";
    private static string ReadVersionLabelFromDevSettings()
    {
        foreach (string dir in DevSettingsCandidateDirs())
        {
            try
            {
                string path = Path.Combine(dir, DevSettingsFileName);
                if (!File.Exists(path)) continue;
                var settings = ReadDevSettings(path);
                string v = ExtractVersion(settings?.VersionLabel);
                if (v.Length > 0) return v;
            }
            catch {   }
        }
        return "";
    }
    private static List<string> DevSettingsCandidateDirs()
    {
        var dirs = new List<string>();
        string exeDir;
        try { exeDir = Path.GetDirectoryName(Path.GetFullPath(InstalledLauncherExe)) ?? ""; }
        catch { return dirs; }
        if (exeDir.Length == 0) return dirs;
        string? dir = exeDir;
        for (int i = 0; i < 10 && !string.IsNullOrEmpty(dir); i++)
        {
            bool isProjectDir = false;
            try { isProjectDir = File.Exists(Path.Combine(dir, DevSettingsProjectMarker)); }
            catch {   }
            if (isProjectDir)
            {
                dirs.Add(dir);
                break;
            }
            string parent = Path.GetDirectoryName(
                dir!.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
            if (string.IsNullOrEmpty(parent) ||
                string.Equals(parent, dir, StringComparison.OrdinalIgnoreCase)) break;
            dir = parent;
        }
        if (!dirs.Contains(exeDir, StringComparer.OrdinalIgnoreCase)) dirs.Add(exeDir);
        return dirs;
    }
    [DataContract]
    private sealed class DevSettingsFile
    {
        [DataMember(Name = "VersionLabel")]
        public string? VersionLabel { get; set; }
    }
    private static DevSettingsFile? ReadDevSettings(string path)
    {
        string json = File.ReadAllText(path);
        if (json.Length == 0) return null;
        var ser = new DataContractJsonSerializer(typeof(DevSettingsFile));
        using var ms = new MemoryStream(Encoding.UTF8.GetBytes(json));
        return ser.ReadObject(ms) as DevSettingsFile;
    }
    private static string SanitizeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
        return name;
    }
    [DataContract]
    public sealed class GhRelease
    {
        [DataMember(Name = "tag_name")] public string tag_name { get; set; } = "";
        [DataMember(Name = "name")] public string name { get; set; } = "";
        [DataMember(Name = "html_url")] public string html_url { get; set; } = "";
        [DataMember(Name = "draft")] public bool draft { get; set; }
        [DataMember(Name = "assets")] public GhAsset[] assets { get; set; } = new GhAsset[0];
    }
    [DataContract]
    public sealed class GhAsset
    {
        [DataMember(Name = "name")] public string name { get; set; } = "";
        [DataMember(Name = "browser_download_url")] public string browser_download_url { get; set; } = "";
        [DataMember(Name = "size")] public long size { get; set; }
    }
    private async void VerifyButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsBusy() || _zipPath == null) return;
        await RunVerifyAsync();
    }
    private async Task RunVerifyAsync()
    {
        if (_zipPath == null) return;
        _busy = true;
        VerifyButton.IsEnabled = false;
        UpdateButton.Visibility = Visibility.Collapsed;
        HideSummary();
        HideError();
        ShowStatus("Đang giải nén và kiểm tra tài nguyên...");
        ProgressB.Visibility = Visibility.Visible;
        ProgressB.IsIndeterminate = false;
        ProgressB.Value = 0;
        try
        {
            var result = await Task.Run(() => VerifyWorker(_zipPath!));
            _packageDir = result.PackageDir;
            _launcherExeRelativePath = result.LauncherExeRelativePath;
            HideStatus();
            ProgressB.Visibility = Visibility.Collapsed;
            ShowSummary($"✔ Bản cập nhật hợp lệ — {result.FileCount} file • {result.TotalMb:0.##} MB\n" +
                        $"✔ Tìm thấy {LauncherExeName} (bắt buộc phải có)\n" +
                        $"Sẵn sàng cập nhật vào:\n{TargetDir}");
            UpdateButton.Visibility = Visibility.Visible;
        }
        catch (Exception ex)
        {
            _packageDir = null;
            _launcherExeRelativePath = null;
            HideStatus();
            ProgressB.Visibility = Visibility.Collapsed;
            ShowError("Xác minh thất bại: " + ex.Message + "\nHãy kiểm tra lại file .zip rồi thử lại.");
            VerifyButton.IsEnabled = true;
        }
        finally
        {
            _busy = false;
        }
    }
    private sealed class VerifyResult
    {
        public string PackageDir = "";
        public string LauncherExeRelativePath = "";
        public int FileCount;
        public double TotalMb;
    }
    private VerifyResult VerifyWorker(string zipPath)
    {
        TryDeleteDirectory(ExtractRoot, 3, 400);
        Directory.CreateDirectory(ExtractRoot);
        int done = 0;
        using (ZipArchive zip = ZipFile.OpenRead(zipPath))
        {
            var fileEntries = zip.Entries.Where(en => !string.IsNullOrEmpty(en.Name)).ToList();
            if (fileEntries.Count == 0)
                throw new InvalidOperationException("File zip trống (không chứa file nào).");
            foreach (ZipArchiveEntry entry in fileEntries)
            {
                if (!IsSafeEntryName(entry.FullName))
                    throw new InvalidOperationException($"File zip chứa đường dẫn không an toàn: {entry.FullName}");
                string dest = GetEntryDestPath(entry.FullName);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                entry.ExtractToFile(dest, true);
                done++;
                if (done % 5 == 0 || done == fileEntries.Count)
                    Dispatch(() =>
                    {
                        StatusText.Text = $"Đang giải nén và kiểm tra... {done}/{fileEntries.Count} file";
                        ProgressB.Value = 100.0 * done / fileEntries.Count;
                    });
            }
        }
        DirectoryInfo? packageDir = FindDirectoryByName(ExtractRoot, TargetFolderName);
        if (packageDir == null)
            throw new InvalidOperationException(
                $"Không tìm thấy thư mục «{TargetFolderName}» bên trong file zip.\n" +
                "Hãy nén nguyên thư mục gốc của bản cập nhật rồi thử lại.");
        List<FileInfo> files = SafeListFiles(packageDir.FullName);
        if (files.Count == 0)
            throw new InvalidOperationException($"Thư mục «{TargetFolderName}» trong file zip trống.");
        FileInfo? launcherExe = files.FirstOrDefault(f =>
            string.Equals(f.Name, LauncherExeName, StringComparison.OrdinalIgnoreCase));
        if (launcherExe == null)
            throw new InvalidOperationException(
                $"Thiếu file {LauncherExeName} — bản cập nhật không đầy đủ tài nguyên.");
        double totalMb = files.Sum(f => f.Length) / 1024.0 / 1024.0;
        string relPath = launcherExe.FullName.Substring(packageDir.FullName.Length).TrimStart('\\', '/');
        Dispatch(() => { StatusText.Text = "Đang tổng hợp kết quả..."; });
        return new VerifyResult
        {
            PackageDir = packageDir.FullName,
            LauncherExeRelativePath = relPath,
            FileCount = files.Count,
            TotalMb = totalMb
        };
    }
    private static bool IsSafeEntryName(string fullName)
    {
        if (string.IsNullOrEmpty(fullName)) return false;
        if (fullName.Contains("..")) return false;
        foreach (char c in fullName)
            if (c == '<' || c == '>' || c == '"' || c == '|' || c == '?' || c == '*' || c < 32)
                return false;
        return !Path.IsPathRooted(fullName.Replace('/', '\\'));
    }
    private string GetEntryDestPath(string entryFullName) =>
        Path.Combine(ExtractRoot, entryFullName.Replace('/', '\\'));
    private async void UpdateButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsBusy()) return;
        if (_packageDir == null || !Directory.Exists(_packageDir))
        {
            ShowError("Dữ liệu xác minh đã bị mất (thư mục tạm bị xóa). Hãy chọn lại file .zip và Xác minh lại.");
            return;
        }
        _busy = true;
        VerifyButton.IsEnabled = false;
        UpdateButton.IsEnabled = false;
        HideSummary();
        HideError();
        ShowStatus("Đang chờ HoYo Launcher đóng hoàn toàn...");
        ProgressB.Visibility = Visibility.Visible;
        ProgressB.IsIndeterminate = true;
        string packageDir = _packageDir;
        string launcherRel = _launcherExeRelativePath ?? "";
        try
        {
            await Task.Run(() => UpdateWorker(packageDir, launcherRel));
            await ShowSuccessAndRelaunch(launcherRel);
        }
        catch (Exception ex)
        {
            HideStatus();
            ProgressB.Visibility = Visibility.Collapsed;
            ShowError("Cập nhật thất bại: " + ex.Message + "\nThư mục launcher hiện tại vẫn được giữ nguyên an toàn.");
            UpdateButton.IsEnabled = true;
        }
        finally
        {
            _busy = false;
        }
    }
    private void UpdateWorker(string packageDir, string launcherRel)
    {
        string baseFull = Path.GetFullPath(BaseDir).TrimEnd('\\') + "\\";
        string targetFull = Path.GetFullPath(TargetDir);
        if (!string.Equals(Path.GetFileName(targetFull.TrimEnd('\\')), TargetFolderName, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Đường dẫn đích không đúng — hủy để bảo vệ dữ liệu.");
        if (!targetFull.StartsWith(baseFull, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Đường dẫn đích nằm ngoài thư mục chương trình — hủy để bảo vệ dữ liệu.");
        Dispatch(() => StatusText.Text = "Đang chờ HoYo Launcher đóng hoàn toàn...");
        for (int i = 0; i < 40; i++)
        {
            if (!IsAnyProcessRunningUnder(targetFull)) break;
            Thread.Sleep(500);
            if (i == 39 && IsAnyProcessRunningUnder(targetFull))
                throw new InvalidOperationException(
                    "HoYo Launcher vẫn đang chạy và không chịu thoát. Hãy đóng launcher rồi bấm «Tiến hành Update» lại.");
        }
        CleanupStaleBackups();
        string? backupDir = null;
        string? starLuxeKeep = null;
        try
        {
            if (Directory.Exists(StarLuxeTargetDir))
            {
                starLuxeKeep = GetUniqueStarLuxeKeepDir();
                Dispatch(() => StatusText.Text = "Đang giữ tài nguyên StarLuxe sang bên (tài nguyên này tải riêng qua tab StarLuxe — bỏ qua khi thay System)...");
                MoveWithRetry(StarLuxeTargetDir, starLuxeKeep);
            }
            if (Directory.Exists(targetFull))
            {
                backupDir = GetUniqueBackupDir(targetFull, DateTime.Now);
                Dispatch(() => StatusText.Text = "Đang lưu bản sao lưu của launcher cũ...");
                MoveWithRetry(targetFull, backupDir);
            }
            Dispatch(() => StatusText.Text = "Đang cài đặt bản cập nhật mới...");
            MoveWithRetry(packageDir, targetFull);
        }
        catch
        {
            if (backupDir != null && Directory.Exists(backupDir) && !Directory.Exists(targetFull))
                MoveWithRetry(backupDir, targetFull);
            if (starLuxeKeep != null && Directory.Exists(starLuxeKeep) && !Directory.Exists(StarLuxeTargetDir))
            {
                try { Directory.Move(starLuxeKeep, StarLuxeTargetDir); } catch { }
            }
            throw;
        }
        PutBackStarLuxeKeep(starLuxeKeep);
        Dispatch(() => StatusText.Text = "Đang dọn dẹp...");
        if (backupDir != null)
            TryDeleteDirectory(backupDir, 5, 600);
        TryDeleteDirectory(ExtractRoot, 5, 600);
        TryDeleteDirectory(DownloadDir, 3, 300);
    }
    private static bool IsAnyProcessRunningUnder(string dir)
    {
        string dirPrefix = Path.GetFullPath(dir).TrimEnd('\\') + "\\";
        foreach (Process p in Process.GetProcesses())
        {
            try
            {
                string? exe = p.MainModule?.FileName;
                if (exe != null &&
                    Path.GetFullPath(exe).StartsWith(dirPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            catch {   }
            finally { p.Dispose(); }
        }
        return false;
    }
    private async Task ShowSuccessAndRelaunch(string launcherRel)
    {
        HideStatus();
        ProgressB.Visibility = Visibility.Collapsed;
        SuccessOverlay.Visibility = Visibility.Visible;
        await Task.Delay(3000);
        try
        {
            string? exe = null;
            if (launcherRel.Length > 0)
            {
                string candidate = Path.Combine(TargetDir, launcherRel);
                if (File.Exists(candidate)) exe = candidate;
            }
            if (exe == null)
                exe = SafeListFiles(TargetDir).FirstOrDefault(f =>
                          string.Equals(f.Name, LauncherExeName, StringComparison.OrdinalIgnoreCase))?.FullName;
            if (exe != null)
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = exe,
                    WorkingDirectory = Path.GetDirectoryName(exe)!,
                    UseShellExecute = true
                });
            }
            else
            {
                foreach (string batName in LauncherBatNames)
                {
                    string bat = Path.Combine(BaseDir, batName);
                    if (!File.Exists(bat)) continue;
                    Process.Start(new ProcessStartInfo { FileName = bat, UseShellExecute = true });
                    break;
                }
            }
        }
        catch {   }
        Application.Current.Shutdown();
    }
    private static DirectoryInfo? FindDirectoryByName(string root, string name)
    {
        DirectoryInfo? best = null;
        int bestDepth = int.MaxValue;
        var queue = new Queue<string>();
        queue.Enqueue(root);
        while (queue.Count > 0)
        {
            string current = queue.Dequeue();
            int depth = CountSeparators(current);
            if (depth >= bestDepth) continue;
            string[] subDirs;
            try { subDirs = Directory.GetDirectories(current); }
            catch { continue; }
            foreach (string sub in subDirs)
            {
                if (string.Equals(Path.GetFileName(sub), name, StringComparison.OrdinalIgnoreCase))
                {
                    best = new DirectoryInfo(sub);
                    bestDepth = depth + 1;
                }
                else
                {
                    queue.Enqueue(sub);
                }
            }
        }
        return best;
    }
    private static int CountSeparators(string path)
    {
        int n = 0;
        foreach (char c in path)
            if (c == '\\' || c == '/') n++;
        return n;
    }
    private static List<FileInfo> SafeListFiles(string dir)
    {
        var result = new List<FileInfo>();
        if (!Directory.Exists(dir)) return result;
        var stack = new Stack<string>();
        stack.Push(dir);
        while (stack.Count > 0)
        {
            string current = stack.Pop();
            string[] files;
            try { files = Directory.GetFiles(current); }
            catch { files = Array.Empty<string>(); }
            foreach (string f in files)
            {
                try { result.Add(new FileInfo(f)); } catch { }
            }
            string[] subDirs;
            try { subDirs = Directory.GetDirectories(current); }
            catch { subDirs = Array.Empty<string>(); }
            foreach (string s in subDirs) stack.Push(s);
        }
        return result;
    }
    private static string GetUniqueBackupDir(string targetDir, DateTime now)
    {
        string stamp = now.ToString("yyyyMMdd_HHmmss");
        string candidate = targetDir + ".bak_" + stamp;
        int n = 2;
        while (Directory.Exists(candidate))
        {
            candidate = targetDir + ".bak_" + stamp + "_" + n;
            n++;
        }
        return candidate;
    }
    private static string GetUniqueStarLuxeKeepDir()
    {
        string candidate = Path.Combine(BaseDir, StarLuxeKeepDirName);
        int n = 2;
        while (Directory.Exists(candidate))
            candidate = Path.Combine(BaseDir, $"{StarLuxeKeepDirName}_{n++}");
        return candidate;
    }
    private void RestoreStaleStarLuxeKeep()
    {
        try
        {
            foreach (string keep in Directory.EnumerateDirectories(BaseDir, StarLuxeKeepDirName + "*"))
            {
                if (!Directory.Exists(StarLuxeTargetDir))
                {
                    try { Directory.Move(keep, StarLuxeTargetDir); continue; }
                    catch { }
                }
                if (Directory.Exists(keep)) TryDeleteDirectory(keep, 2, 300);
            }
        }
        catch { }
    }
    private void PutBackStarLuxeKeep(string? starLuxeKeep)
    {
        if (starLuxeKeep == null || !Directory.Exists(starLuxeKeep)) return;
        try
        {
            if (Directory.Exists(StarLuxeTargetDir))
                TryDeleteDirectory(StarLuxeTargetDir, 3, 400);
            MoveWithRetry(starLuxeKeep, StarLuxeTargetDir);
            Dispatch(() => StatusText.Text = "Đã trả tài nguyên StarLuxe về System\\StarLuxe.");
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                "Đã cài bản cập nhật xong, NHƯNG không đưa được tài nguyên StarLuxe về «System\\StarLuxe» (" +
                ex.Message + "). Tài nguyên vẫn nằm ở: " + starLuxeKeep +
                " — mở lại trình Update này sẽ tự đưa nó về đúng chỗ, hoặc di chuyển thủ công.");
        }
    }
    private void CleanupStaleBackups()
    {
        try
        {
            foreach (string d in Directory.EnumerateDirectories(BaseDir, TargetFolderName + ".bak_*"))
                TryDeleteDirectory(d, 2, 300);
        }
        catch { }
    }
    private void CleanupStaleTemp()
    {
        TryDeleteDirectory(ExtractRoot, 3, 300);
        TryDeleteDirectory(DownloadDir, 2, 200);
    }
    private static void MoveWithRetry(string src, string dst)
    {
        Exception? last = null;
        for (int i = 0; i < 3; i++)
        {
            try
            {
                if (Directory.Exists(dst))
                    throw new IOException($"Thư mục đích đã tồn tại: {dst}");
                Directory.Move(src, dst);
                return;
            }
            catch (Exception ex)
            {
                last = ex;
                Thread.Sleep(500);
            }
        }
        throw last!;
    }
    private static void TryDeleteDirectory(string path, int attempts, int delayMs)
    {
        for (int i = 0; i < attempts; i++)
        {
            try
            {
                if (!Directory.Exists(path)) return;
                Directory.Delete(path, true);
                return;
            }
            catch
            {
                if (i < attempts - 1) Thread.Sleep(delayMs);
            }
        }
    }
    private bool IsBusy() => _busy;
    private void Dispatch(Action action) => Dispatcher.Invoke(action);
    private void SetDropZoneHighlight(bool on)
    {
        DropZone.Background = on ? "#1A2334".ToBrush() : "#141820".ToBrush();
        DropZone.BorderBrush = on ? "#5B8DEF".ToBrush() : "#2A3242".ToBrush();
        DropZoneOutline.Stroke = on ? "#5B8DEF".ToBrush() : "#2A3242".ToBrush();
    }
    private void ShowStatus(string text)
    {
        StatusText.Visibility = Visibility.Visible;
        StatusText.Text = text;
    }
    private void HideStatus() => StatusText.Visibility = Visibility.Collapsed;
    private void ShowSummary(string text)
    {
        SummaryPanel.Visibility = Visibility.Visible;
        SummaryText.Text = text;
    }
    private void HideSummary() => SummaryPanel.Visibility = Visibility.Collapsed;
    private void ShowError(string text)
    {
        ErrorPanel.Visibility = Visibility.Visible;
        ErrorText.Text = text;
    }
    private void HideError() => ErrorPanel.Visibility = Visibility.Collapsed;
}
internal static class BrushExtensions
{
    public static System.Windows.Media.SolidColorBrush ToBrush(this string hex) =>
        (System.Windows.Media.SolidColorBrush)new System.Windows.Media.BrushConverter().ConvertFromString(hex);
}
