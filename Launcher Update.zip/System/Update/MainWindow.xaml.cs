using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;

namespace HoYoLauncherUpdate;

public partial class MainWindow : Window
{
    // ============ HẰNG SỐ & ĐƯỜNG DẪN ============

    /// <summary>Tên thư mục launcher — cũng là thư mục DUY NHẤT được phép xóa/thay thế.</summary>
    private const string TargetFolderName = "System";

    /// <summary>Thư mục con chứa file exe của launcher, tính từ <see cref="TargetDir"/>.
    /// Output đã được rút phẳng còn 1 cấp để tránh vượt giới hạn 260 ký tự của Windows, nên bản
    /// cập nhật phải tìm exe ở System\Resources\bin\HoYoLauncher.exe chứ không ở gốc System\.</summary>
    private const string LauncherSubFolder = @"Resources\bin";

    /// <summary>File exe chính của launcher bên trong bản cập nhật — dùng kiểm tra "đủ tài nguyên".</summary>
    private const string LauncherExeName = "HoYoLauncher.exe";

    /// <summary>Tên file .bat khởi chạy launcher ở thư mục gốc — nhận CẢ HAI tên.
    /// Bản phát hành hiện tại đặt tên <c>HoYoLauncher.bat</c>, còn cây nguồn <c>C:\HoYo Launcher\...</c>
    /// đặt tên <c>System.bat</c>; nhận cả hai để updater mở lại launcher được ở mọi bản phát hành.
    /// Thứ tự: ưu tiên <c>System.bat</c> (khớp với tên thư mục "System").</summary>
    private static readonly string[] LauncherBatNames = { "System.bat", "HoYoLauncher.bat" };

    /// <summary>Thư mục chứa chính file exe của trình cập nhật (= C:\HoYo Launcher\HoYo_Launcher_v2.1.04 khi triển khai).</summary>
    private static string BaseDir => AppDomain.CurrentDomain.BaseDirectory;

    /// <summary>Thư mục launcher sẽ bị thay thế: BaseDir\System. Các thư mục cùng cấp KHÔNG bị động tới.</summary>
    private static string TargetDir => Path.Combine(BaseDir, TargetFolderName);

    /// <summary>Đường dẫn tuyệt đối tới file exe launcher đang cài:
    /// BaseDir\System\Resources\bin\HoYoLauncher.exe.</summary>
    private static string InstalledLauncherExe =>
        Path.Combine(TargetDir, LauncherSubFolder, LauncherExeName);

    /// <summary>Tên thư mục tạm chứa bản giải nén, nằm cạnh launcher (cùng ổ đĩa).</summary>
    private const string TempExtractDirName = "launcher Update.tmp";

    /// <summary>
    /// Nơi giải nén file zip để kiểm tra — nằm NGAY trong thư mục chứa trình cập nhật, tức thư mục
    /// gốc của bản cài (cùng ổ đĩa với <see cref="TargetDir"/>).
    ///
    /// TRƯỚC ĐÂY dùng %TEMP% — luôn nằm ở ổ C:. Khi người dùng cài launcher ở ổ khác (D:, E:...),
    /// bước "chuyển thư mục mới vào chỗ" phải COPY chéo ổ đĩa cho cả thư mục launcher (~hàng trăm
    /// MB, hàng trăm file) thay vì RENAME: chậm, dễ vướng giới hạn 260 ký tự khi copy từng file,
    /// và bỏ sót hàng trăm MB rác ở %TEMP% của ổ C:.
    /// Đặt cạnh launcher thì <c>Directory.Move</c> là RENAME trong cùng volume — gần như tức thì
    /// và không tốn thêm dung lượng cho bước copy.
    ///
    /// Được dọn NGAY sau khi cập nhật xong (xem <see cref="UpdateWorker"/>), đồng thời dọn nốt
    /// thư mục tạm sót lại từ lần chạy bị gián đoạn (xem <see cref="CleanupStaleTemp"/>).
    /// </summary>
    private static string ExtractRoot => Path.Combine(BaseDir, TempExtractDirName);

    // ============ GITHUB RELEASES (nút "Tải Xuống Bản Cập Nhật Mới Nhất") ============

    /// <summary>Repo GitHub chứa release của launcher — trùng với LauncherUpdateService bên launcher.</summary>
    private const string RepoOwner = "manh00937-ui";
    private const string RepoName = "HoYo_Launcher_Mods";

    /// <summary>Endpoint "release mới nhất"; nếu trả 404 (repo chưa đánh dấu latest) thì rơi sang
    /// danh sách release và lấy bản đầu tiên không phải draft.</summary>
    private const string LatestReleaseUrl = $"https://api.github.com/repos/{RepoOwner}/{RepoName}/releases/latest";
    private const string ReleaseListUrl = $"https://api.github.com/repos/{RepoOwner}/{RepoName}/releases?per_page=5";

    /// <summary>Tên thư mục tạm chứa file .zip tải từ GitHub.</summary>
    private const string TempDownloadDirName = "launcher Update.download";

    /// <summary>Nơi giữ file .zip tải về từ GitHub — cùng thư mục gốc với launcher (cùng ổ đĩa),
    /// và cũng được dọn ngay sau khi cập nhật xong. Vẫn tách khỏi <see cref="ExtractRoot"/> vì bước
    /// xác minh xóa sạch thư mục giải nén mỗi lần chạy — zip tải về sẽ bị mất vô ích.
    /// File .zip người dùng TỰ chọn qua hộp thoại không nằm ở đây nên không bị đụng tới.</summary>
    private static string DownloadDir => Path.Combine(BaseDir, TempDownloadDirName);

    // ============ TRẠNG THÁI ============

    private string? _zipPath;                 // file .zip người dùng đã chọn
    private string? _packageDir;              // thư mục "System" đã giải nén (đã xác minh)
    private string? _launcherExeRelativePath; // đường dẫn exe launcher tính từ _packageDir

    private bool _busy; // đang xác minh / cập nhật — khóa thao tác tránh chạy chồng

    public MainWindow()
    {
        InitializeComponent();

        // QUAN TRỌNG: nếu được launcher mở bằng cách "kế thừa" vị trí làm việc (CurrentDirectory)
        // nằm BÊN TRONG thư mục launcher, Windows sẽ coi thư mục đó đang bị "giữ" và từ chối
        // đổi tên/xóa khi cập nhật. Đặt lại vị trí làm việc về thư mục của chính trình cập
        // nhật (nằm NGOÀI thư mục được cập nhật) để giải phóng khóa này ngay từ đầu.
        try { Environment.CurrentDirectory = BaseDir; } catch { }

        CleanupStaleBackups();
        CleanupStaleTemp();
    }

    // =====================================================================
    //  NHẬN FILE ZIP (kéo thả toàn cửa sổ + duyệt file)
    // =====================================================================

    private void BrowseButton_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "Chọn file .zip bản cập nhật",
            Filter = "File zip (*.zip)|*.zip",
            CheckFileExists = true
        };
        if (dlg.ShowDialog(this) == true)
            AcceptZip(dlg.FileName);
    }

    // Kéo thả có độ bao phủ TOÀN CỬA SỔ: 3 handler dưới đăng ký trên Window, nên thả ở đâu cũng nhận.
    private void Window_DragOver(object sender, DragEventArgs e)
    {
        bool ok = !IsBusy() && GetDroppedZip(e) != null;
        e.Effects = ok ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
        SetDropZoneHighlight(ok);
    }

    private void Window_DragLeave(object sender, DragEventArgs e)
    {
        SetDropZoneHighlight(false);
    }

    private void Window_Drop(object sender, DragEventArgs e)
    {
        SetDropZoneHighlight(false);
        if (IsBusy()) return;

        string? zip = GetDroppedZip(e);
        if (zip == null)
        {
            ShowError("Chỉ nhận file .zip. Hãy kéo thả file .zip của bản cập nhật vào đây.");
            return;
        }
        AcceptZip(zip);
    }

    /// <summary>Lấy file .zip đầu tiên từ dữ liệu kéo thả (nếu có).</summary>
    private static string? GetDroppedZip(DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return null;
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return null;
        return files.FirstOrDefault(f =>
            File.Exists(f) &&
            string.Equals(Path.GetExtension(f), ".zip", StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Ghi nhận file zip vừa chọn: hiện thông tin, sáng nút Xác minh, Reset trạng thái cũ.</summary>
    private void AcceptZip(string zipPath)
    {
        _zipPath = zipPath;
        _packageDir = null;
        _launcherExeRelativePath = null;

        FileInfoPanel.Visibility = Visibility.Visible;
        ZipNameText.Text = Path.GetFileName(zipPath);
        try
        {
            long bytes = new FileInfo(zipPath).Length;
            ZipSizeText.Text = $"{bytes / 1024.0 / 1024.0:0.##} MB";
        }
        catch { ZipSizeText.Text = ""; }

        VerifyButton.IsEnabled = true;
        UpdateButton.Visibility = Visibility.Collapsed;
        HideStatus();
        HideSummary();
        HideError();
    }

    // =====================================================================
    //  TẢI BẢN MỚI NHẤT TỪ GITHUB RELEASES
    // =====================================================================

    /// <summary>Nút "⬇ Tải Xuống Bản Cập Nhật Mới Nhất": đọc release mới nhất trên GitHub,
    /// tải file .zip đính kèm về %TEMP% rồi TỰ XÁC MINH — người dùng chỉ còn bấm
    /// "⚡ Tiến hành Update" (giống hệt luồng kéo thả file .zip thủ công, dùng khi mất mạng).</summary>
    private async void DownloadLatestButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsBusy()) return;

        _busy = true;
        DownloadLatestButton.IsEnabled = false;
        HideSummary();
        HideError();

        try
        {
            string? zipPath = await DownloadLatestAsync();
            if (zipPath == null) return; // lỗi / thông báo đã hiển thị sẵn trong DownloadLatestAsync

            AcceptZip(zipPath);          // hiện thông tin file + sáng nút Xác minh (giống kéo thả)
            _busy = false;               // trả cờ "bận" cho bước xác minh — RunVerifyAsync tự khóa lại
            await RunVerifyAsync();      // tải xong tự xác minh, người dùng chỉ còn bấm Tiến hành Update
        }
        catch (Exception ex)
        {
            ShowDownloadError("Tải bản cập nhật thất bại: " + ex.Message +
                              "\nBạn vẫn có thể kéo thả file .zip bản mới vào cửa sổ này nếu đã tải sẵn.");
        }
        finally
        {
            _busy = false;
            DownloadLatestButton.IsEnabled = true;
            ProgressB.Visibility = Visibility.Collapsed;
        }
    }

    /// <summary>Tải gói .zip mới nhất từ GitHub Releases về <see cref="DownloadDir"/> và trả về
    /// đường dẫn file đó. Trả về null = không tải được / người dùng hủy — khi đó thông báo lỗi
    /// hoặc hộp thoại xác nhận đã được hiển thị sẵn trên giao diện.</summary>
    private async Task<string?> DownloadLatestAsync()
    {
        ProgressB.Visibility = Visibility.Visible;
        ProgressB.IsIndeterminate = true;
        ProgressB.Value = 0;
        ShowStatus("Đang kiểm tra bản cập nhật mới nhất trên GitHub...");

        try
        {
            // ---- 1) Release mới nhất ----
            GhRelease? release = await FetchLatestReleaseAsync();
            if (release == null)
            {
                ShowDownloadError("GitHub chưa có bản phát hành (release) nào cho HoYo Launcher Mods.");
                return null;
            }

            // ---- 2) File .zip đính kèm (ưu tiên gói có chữ "hoyo" như launcher) ----
            var zips = (release.assets ?? new GhAsset[0])
                .Where(a => a != null && !string.IsNullOrEmpty(a.name) &&
                            !string.IsNullOrEmpty(a.browser_download_url) &&
                            a.name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                .ToList();
            GhAsset? asset = zips.FirstOrDefault(a =>
                                 a.name.IndexOf("hoyo", StringComparison.OrdinalIgnoreCase) >= 0)
                             ?? zips.FirstOrDefault();
            if (asset == null)
            {
                ShowDownloadError("Release «" + ReleaseTitle(release) +
                                  "» không có file .zip nào để tải.\n" +
                                  "Bạn hãy tải file .zip bản mới tại trang release của GitHub.");
                return null;
            }

            // ---- 3) Đang dùng bản mới nhất rồi -> hỏi trước khi tải cho đỡ tốn dung lượng ----
            string latest = ExtractVersion(release.tag_name);
            if (latest.Length == 0) latest = ExtractVersion(release.name);
            string installed = InstalledLauncherVersion();
            if (latest.Length > 0 && installed.Length > 0 && !IsNewer(latest, installed))
            {
                HideStatus();
                ProgressB.Visibility = Visibility.Collapsed;
                var answer = MessageBox.Show(
                    $"Phiên bản đang cài:  {installed}\n" +
                    $"Bản mới nhất trên GitHub:  {latest}\n\n" +
                    "Bạn ĐANG dùng bản mới nhất rồi. Vẫn muốn tải lại file .zip ?",
                    "Không có Update mới", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (answer != MessageBoxResult.Yes) return null;

                ProgressB.Visibility = Visibility.Visible;
                ProgressB.IsIndeterminate = false;
                ShowStatus($"Đang tải {asset.name} từ GitHub...");
            }

            // ---- 4) Tải file về thư mục tạm cạnh launcher (cùng ổ đĩa) ----
            Directory.CreateDirectory(DownloadDir);
            string zipPath = Path.Combine(DownloadDir, SanitizeFileName(asset.name));
            if (File.Exists(zipPath))
            {
                try { File.Delete(zipPath); } catch { /* file cũ đang bị giữ -> tải xuống tên mới sẽ ghi đè khi xong */ }
            }

            ProgressB.Visibility = Visibility.Visible;
            ProgressB.IsIndeterminate = false;
            ProgressB.Value = 0;
            ShowStatus($"Đang tải {asset.name} từ GitHub...");

            long lastLoggedMb = 0;
            using (var wc = CreateWebClient())
            {
                wc.DownloadProgressChanged += (_, args) =>
                {
                    ProgressB.Value = args.ProgressPercentage;

                    // Chỉ cập nhật chữ mỗi khi thêm >= 1 MB (hoặc đã xong) — tránh repaint liên tục
                    long mb = args.BytesReceived / 1048576;
                    if (mb == lastLoggedMb && args.ProgressPercentage < 100) return;
                    lastLoggedMb = mb;

                    string received = (args.BytesReceived / 1048576.0).ToString("0.#");
                    string total = args.TotalBytesToReceive > 0
                        ? "/" + (args.TotalBytesToReceive / 1048576.0).ToString("0.#")
                        : "";
                    StatusText.Text = $"Đang tải từ GitHub... {received}{total} MB ({args.ProgressPercentage}%)";
                };
                await wc.DownloadFileTaskAsync(asset.browser_download_url, zipPath);
            }

            if (!File.Exists(zipPath) || new FileInfo(zipPath).Length == 0)
            {
                ShowDownloadError("Tải file thất bại (file rỗng) — kiểm tra kết nối mạng rồi thử lại.");
                return null;
            }

            HideStatus();
            return zipPath;
        }
        catch (WebException ex)
        {
            ShowDownloadError(DescribeWebError(ex));
            return null;
        }
        catch (Exception ex)
        {
            ShowDownloadError("Tải bản cập nhật thất bại: " + ex.Message);
            return null;
        }
    }

    /// <summary>Đọc release mới nhất từ GitHub API: ưu tiên endpoint /releases/latest, nếu 404
    /// (repo chưa đánh dấu release nào là latest) thì lấy bản đầu tiên trong danh sách release
    /// (bỏ qua draft). Ném lỗi mạng ra ngoài để hiển thị thông báo tiếng Việt.</summary>
    private static async Task<GhRelease?> FetchLatestReleaseAsync()
    {
        try
        {
            var rel = FromJson<GhRelease>(await DownloadStringAsync(LatestReleaseUrl));
            if (rel != null && !rel.draft) return rel;
        }
        catch (WebException ex) when (IsHttp404(ex))
        {
            // endpoint "latest" không có -> rơi sang danh sách release bên dưới
        }

        var list = FromJson<List<GhRelease>>(await DownloadStringAsync(ReleaseListUrl));
        return list?.FirstOrDefault(r => r != null && !r.draft);
    }

    /// <summary>GET JSON kèm header User-Agent (bắt buộc với GitHub API) — dùng WebClient có sẵn
    /// của .NET Framework nên không cần tham chiếu thêm thư viện HTTP nào.</summary>
    private static async Task<string> DownloadStringAsync(string url)
    {
        using var wc = CreateWebClient();
        return await wc.DownloadStringTaskAsync(url);
    }

    private static WebClient CreateWebClient()
    {
        var wc = new WebClient();
        wc.Encoding = System.Text.Encoding.UTF8;
        // GitHub API từ chối request không có User-Agent.
        wc.Headers.Add(HttpRequestHeader.UserAgent, "HoYoLauncherUpdate");
        wc.Headers.Add(HttpRequestHeader.Accept, "application/vnd.github+json");
        return wc;
    }

    /// <summary>Parse JSON (release / danh sách release) bằng DataContractJsonSerializer có sẵn của
    /// .NET Framework. Trường lạ trong response của GitHub bị bỏ qua tự nhiên — ta chỉ đọc các
    /// trường khai báo ở <see cref="GhRelease"/>/<see cref="GhAsset"/>.</summary>
    private static T? FromJson<T>(string json) where T : class
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json));
        return new DataContractJsonSerializer(typeof(T)).ReadObject(stream) as T;
    }

    private static bool IsHttp404(WebException ex) =>
        ex.Response is HttpWebResponse resp && resp.StatusCode == HttpStatusCode.NotFound;

    /// <summary>Đổi lỗi WebException thành thông báo dễ hiểu cho người dùng.</summary>
    private static string DescribeWebError(WebException ex)
    {
        if (ex.Response is HttpWebResponse resp)
        {
            if (resp.StatusCode == HttpStatusCode.NotFound)
                return "Không tìm thấy file trên GitHub (lỗi 404) — release có thể đã bị xoá.";
            if (resp.StatusCode == HttpStatusCode.Forbidden)
                return "GitHub đang giới hạn số yêu cầu từ mạng của bạn (lỗi 403) — thử lại sau ít phút.";
            return $"GitHub trả lỗi {(int)resp.StatusCode} {resp.StatusDescription} — thử lại sau.";
        }
        return "Không kết nối được tới GitHub — kiểm tra kết nối mạng rồi thử lại.\n" + ex.Message;
    }

    /// <summary>Chặn hiện lỗi của luồng tải: dừng tiến trình + hiện bảng lỗi đỏ (bỏ trạng thái).</summary>
    private void ShowDownloadError(string text)
    {
        HideStatus();
        ProgressB.Visibility = Visibility.Collapsed;
        ShowError(text);
    }

    private static string ReleaseTitle(GhRelease r) =>
        !string.IsNullOrWhiteSpace(r.name) ? r.name : r.tag_name;

    // ---- So sánh phiên bản (đọc version launcher đang cài từ file exe) ----

    private static readonly Regex VersionPattern = new Regex(@"\d+(?:\.\d+)+", RegexOptions.Compiled);

    /// <summary>Lấy chuỗi "2.0.12" từ tag/name release ("HoYo-Launcher-v2.0.12").</summary>
    private static string ExtractVersion(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        var m = VersionPattern.Match(text);
        return m.Success ? m.Value : "";
    }

    /// <summary>Đúng nghĩa đen: <paramref name="candidate"/> có MỚI HƠN <paramref name="current"/>
    /// không (so sánh từng phần số: 2.0.12 > 2.0.11, 2.1 > 2.0.9...). Không so sánh được -> false.</summary>
    private static bool IsNewer(string candidate, string current)
    {
        int[] a = SplitVersion(candidate), b = SplitVersion(current);
        if (a.Length == 0 || b.Length == 0) return false;
        for (int i = 0; i < Math.Max(a.Length, b.Length); i++)
        {
            int x = i < a.Length ? a[i] : 0;
            int y = i < b.Length ? b[i] : 0;
            if (x != y) return x > y;
        }
        return false;
    }

    private static int[] SplitVersion(string v)
    {
        if (string.IsNullOrWhiteSpace(v)) return new int[0];
        string[] parts = v.Split('.');
        var nums = new int[parts.Length];
        for (int i = 0; i < parts.Length; i++)
            nums[i] = int.TryParse(parts[i], out int n) ? n : 0;
        return nums;
    }

    /// <summary>Phiên bản launcher ĐANG CÀI.
    ///
    /// ƯU TIÊN đọc <c>VersionLabel</c> trong devsettings.json — đó chính là tên phiên bản launcher
    /// thật sự hiển thị (tiêu đề cửa sổ), và cũng là thứ launcher tự dùng để tự so
    /// (<c>LauncherUpdateService.CurrentVersion = DevSettingsService.DisplayVersion(BuildVersion)</c>).
    ///
    /// Trước đây updater đọc Win32 FileVersion của file .exe. Hai nguồn này có thể LỆCH nhau: bạn
    /// sửa VersionLabel trong devsettings.json lên bản mới nhưng quên build lại /build vẫn ghi
    /// phiên bản cũ — lúc đó updater thấy launcher "cũ" hơn bản phát hành và CỨ HỎI CẬP NHẬT mãi,
    /// dù launcher bên trong đã là bản mới. Đọc chung một nguồn với launcher là hết lệch.
    ///
    /// Không có devsettings.json hoặc VersionLabel rỗng -> rơi về FileVersion của exe.
    /// Không đọc được gì -> "" (khi đó cứ tải bình thường, không hỏi lại).</summary>
    private static string InstalledLauncherVersion()
    {
        try
        {
            string label = ReadVersionLabelFromDevSettings();
            if (label.Length > 0) return label;
        }
        catch { }

        try
        {
            string exe = InstalledLauncherExe;
            return File.Exists(exe)
                ? ExtractVersion(FileVersionInfo.GetVersionInfo(exe).FileVersion)
                : "";
        }
        catch { return ""; }
    }

    /// <summary>Tên file cấu hình nhà phát triển của launcher (trùng với DevSettingsService).</summary>
    private const string DevSettingsFileName = "devsettings.json";

    /// <summary>Dấu hiệu thư mục project launcher — dùng để tìm devsettings.json ưu tiên bản
    /// cạnh .csproj (bản này sống sót qua lần build lại), giống DevSettingsService.ResolveProjectPath.</summary>
    private const string DevSettingsProjectMarker = "HoYoLauncher.csproj";

    /// <summary>Đọc <c>VersionLabel</c> từ devsettings.json và trả về dạng chỉ gồm số ("2.1.06",
    /// đã bỏ chữ "v"). Trả "" nếu không có file, không đọc được, hoặc VersionLabel rỗng.</summary>
    private static string ReadVersionLabelFromDevSettings()
    {
        foreach (string dir in DevSettingsCandidateDirs())
        {
            try
            {
                string path = Path.Combine(dir, DevSettingsFileName);
                if (!File.Exists(path)) continue;

                var settings = ReadDevSettings(path);
                string v = ExtractVersion(settings?.VersionLabel);
                if (v.Length > 0) return v;
            }
            catch { /* file hỏng / không đọc được -> thử vị trí tiếp theo */ }
        }
        return "";
    }

    /// <summary>Các thư mục có thể chứa devsettings.json, theo đúng thứ tự launcher ưu tiên:
    /// thư mục chứa .csproj (đi ngược từ thư mục .exe), rồi tới thư mục cạnh .exe
    /// (bản đóng gói gọn không có mã nguồn).</summary>
    private static List<string> DevSettingsCandidateDirs()
    {
        var dirs = new List<string>();

        string exeDir;
        try { exeDir = Path.GetDirectoryName(Path.GetFullPath(InstalledLauncherExe)) ?? ""; }
        catch { return dirs; }
        if (exeDir.Length == 0) return dirs;

        // 1) đi ngược từ thư mục .exe tìm thư mục có .csproj (giống DevSettingsService.ResolveProjectPath)
        string? dir = exeDir;
        for (int i = 0; i < 10 && !string.IsNullOrEmpty(dir); i++)
        {
            bool isProjectDir = false;
            try { isProjectDir = File.Exists(Path.Combine(dir, DevSettingsProjectMarker)); }
            catch { /* đường dẫn lạ — coi như không phải thư mục project */ }

            if (isProjectDir)
            {
                dirs.Add(dir);
                break;
            }

            string parent = Path.GetDirectoryName(
                dir!.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
            if (string.IsNullOrEmpty(parent) ||
                string.Equals(parent, dir, StringComparison.OrdinalIgnoreCase)) break;
            dir = parent;
        }

        // 2) thư mục cạnh .exe — dành cho bản đóng gói gọn không kèm mã nguồn
        if (!dirs.Contains(exeDir, StringComparer.OrdinalIgnoreCase)) dirs.Add(exeDir);
        return dirs;
    }

    /// <summary>Chỉ cần field VersionLabel — DataContractJsonSerializer bỏ qua các field khác
    /// trong file (OrfixCheckUrl, TabLabels...) nên không cần khai báo đầy đủ cấu trúc.</summary>
    [DataContract]
    private sealed class DevSettingsFile
    {
        [DataMember(Name = "VersionLabel")]
        public string? VersionLabel { get; set; }
    }

    private static DevSettingsFile? ReadDevSettings(string path)
    {
        // Đọc ra TEXT trước rồi mới parse. Nếu mở stream thẳng, file devsettings.json bị ghi kèm
        // BOM (rất dễ xảy ra khi admin sửa bằng Notepad/Excel, hay script PowerShell) sẽ khiến
        // DataContractJsonSerializer ném lỗi và ta âm thầm rơi về đọc FileVersion của exe.
        // File.ReadAllText tự nhận diện và loại BOM — giống hệt DevSettingsService bên launcher.
        string json = File.ReadAllText(path);
        if (json.Length == 0) return null;

        var ser = new DataContractJsonSerializer(typeof(DevSettingsFile));
        using var ms = new MemoryStream(Encoding.UTF8.GetBytes(json));
        return ser.ReadObject(ms) as DevSettingsFile;
    }

    private static string SanitizeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
        return name;
    }

    /// <summary>Một release trên GitHub — Name trùng đúng khóa JSON (tag_name, html_url...).
    /// net48 không có System.Text.Json nên dùng DataContractJsonSerializer của .NET Framework.</summary>
    [DataContract]
    public sealed class GhRelease
    {
        [DataMember(Name = "tag_name")] public string tag_name { get; set; } = "";
        [DataMember(Name = "name")] public string name { get; set; } = "";
        [DataMember(Name = "html_url")] public string html_url { get; set; } = "";
        [DataMember(Name = "draft")] public bool draft { get; set; }
        [DataMember(Name = "assets")] public GhAsset[] assets { get; set; } = new GhAsset[0];
    }

    /// <summary>File đính kèm trong release — "browser_download_url" là liên kết tải trực tiếp.</summary>
    [DataContract]
    public sealed class GhAsset
    {
        [DataMember(Name = "name")] public string name { get; set; } = "";
        [DataMember(Name = "browser_download_url")] public string browser_download_url { get; set; } = "";
        [DataMember(Name = "size")] public long size { get; set; }
    }

    // =====================================================================
    //  BƯỚC 1 — XÁC MINH: giải nén + kiểm tra đầy đủ tài nguyên
    // =====================================================================

    private async void VerifyButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsBusy() || _zipPath == null) return;
        await RunVerifyAsync();
    }

    /// <summary>Bước 1 — xác minh bản cập nhật (giải nén + kiểm tra tài nguyên). Dùng chung cho cả
    /// hai luồng: người dùng chọn file .zip thủ công và luồng tải tự động từ GitHub. Tự khóa cờ
    /// <see cref="_busy"/> trong suốt quá trình, trả về khi đã xong (kể cả khi thất bại).</summary>
    private async Task RunVerifyAsync()
    {
        if (_zipPath == null) return;
        _busy = true;

        VerifyButton.IsEnabled = false;
        UpdateButton.Visibility = Visibility.Collapsed;
        HideSummary();
        HideError();
        ShowStatus("Đang giải nén và kiểm tra tài nguyên...");
        ProgressB.Visibility = Visibility.Visible;
        ProgressB.IsIndeterminate = false;
        ProgressB.Value = 0;

        try
        {
            var result = await Task.Run(() => VerifyWorker(_zipPath!));

            // Xác minh thành công -> hiện nút Tiến hành Update
            _packageDir = result.PackageDir;
            _launcherExeRelativePath = result.LauncherExeRelativePath;
            HideStatus();
            ProgressB.Visibility = Visibility.Collapsed;
            ShowSummary($"✔ Bản cập nhật hợp lệ — {result.FileCount} file • {result.TotalMb:0.##} MB\n" +
                        $"✔ Tìm thấy {LauncherExeName} (bắt buộc phải có)\n" +
                        $"Sẵn sàng cập nhật vào:\n{TargetDir}");
            UpdateButton.Visibility = Visibility.Visible;
        }
        catch (Exception ex)
        {
            _packageDir = null;
            _launcherExeRelativePath = null;
            HideStatus();
            ProgressB.Visibility = Visibility.Collapsed;
            ShowError("Xác minh thất bại: " + ex.Message + "\nHãy kiểm tra lại file .zip rồi thử lại.");
            VerifyButton.IsEnabled = true;
        }
        finally
        {
            _busy = false;
        }
    }

    private sealed class VerifyResult
    {
        public string PackageDir = "";
        public string LauncherExeRelativePath = "";
        public int FileCount;
        public double TotalMb;
    }

    /// <summary>Toàn bộ việc giải nén + kiểm tra — chạy trong luồng nền để giao diện không đơ.</summary>
    private VerifyResult VerifyWorker(string zipPath)
    {
        // Dọn thư mục giải nén cũ (nếu còn sót từ lần trước)
        TryDeleteDirectory(ExtractRoot, 3, 400);
        Directory.CreateDirectory(ExtractRoot);

        // ---- Giải nén từng mục với kiểm tra an toàn đường dẫn ----
        int done = 0;
        using (ZipArchive zip = ZipFile.OpenRead(zipPath))
        {
            var fileEntries = zip.Entries.Where(en => !string.IsNullOrEmpty(en.Name)).ToList();
            if (fileEntries.Count == 0)
                throw new InvalidOperationException("File zip trống (không chứa file nào).");

            foreach (ZipArchiveEntry entry in fileEntries)
            {
                if (!IsSafeEntryName(entry.FullName))
                    throw new InvalidOperationException($"File zip chứa đường dẫn không an toàn: {entry.FullName}");

                string dest = GetEntryDestPath(entry.FullName);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);

                // Overwrite=true: trường hợp zip có 2 entry trùng tên thì lấy bản sau
                entry.ExtractToFile(dest, true);

                done++;
                if (done % 5 == 0 || done == fileEntries.Count)
                    Dispatch(() =>
                    {
                        StatusText.Text = $"Đang giải nén và kiểm tra... {done}/{fileEntries.Count} file";
                        ProgressB.Value = 100.0 * done / fileEntries.Count;
                    });
            }
        }

        // ---- Tìm thư mục "System" (nông nhất nếu có nhiều) ----
        DirectoryInfo? packageDir = FindDirectoryByName(ExtractRoot, TargetFolderName);
        if (packageDir == null)
            throw new InvalidOperationException(
                $"Không tìm thấy thư mục «{TargetFolderName}» bên trong file zip.\n" +
                "Hãy nén nguyên thư mục gốc của bản cập nhật rồi thử lại.");

        // ---- Kiểm tra "đủ tài nguyên": phải có file exe của launcher ----
        List<FileInfo> files = SafeListFiles(packageDir.FullName);
        if (files.Count == 0)
            throw new InvalidOperationException($"Thư mục «{TargetFolderName}» trong file zip trống.");

        FileInfo? launcherExe = files.FirstOrDefault(f =>
            string.Equals(f.Name, LauncherExeName, StringComparison.OrdinalIgnoreCase));
        if (launcherExe == null)
            throw new InvalidOperationException(
                $"Thiếu file {LauncherExeName} — bản cập nhật không đầy đủ tài nguyên.");

        double totalMb = files.Sum(f => f.Length) / 1024.0 / 1024.0;
        string relPath = launcherExe.FullName.Substring(packageDir.FullName.Length).TrimStart('\\', '/');

        Dispatch(() => { StatusText.Text = "Đang tổng hợp kết quả..."; });
        return new VerifyResult
        {
            PackageDir = packageDir.FullName,
            LauncherExeRelativePath = relPath,
            FileCount = files.Count,
            TotalMb = totalMb
        };
    }

    /// <summary>Tên entry hợp lệ: không chứa "..", không chứa ký tự cấm, không phải đường dẫn tuyệt đối.</summary>
    private static bool IsSafeEntryName(string fullName)
    {
        if (string.IsNullOrEmpty(fullName)) return false;
        if (fullName.Contains("..")) return false;
        foreach (char c in fullName)
            if (c == '<' || c == '>' || c == '"' || c == '|' || c == '?' || c == '*' || c < 32)
                return false;
        return !Path.IsPathRooted(fullName.Replace('/', '\\'));
    }

    private string GetEntryDestPath(string entryFullName) =>
        Path.Combine(ExtractRoot, entryFullName.Replace('/', '\\'));

    // =====================================================================
    //  BƯỚC 2 — TIẾN HÀNH UPDATE
    // =====================================================================

    private async void UpdateButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsBusy()) return;
        if (_packageDir == null || !Directory.Exists(_packageDir))
        {
            ShowError("Dữ liệu xác minh đã bị mất (thư mục tạm bị xóa). Hãy chọn lại file .zip và Xác minh lại.");
            return;
        }
        _busy = true;

        VerifyButton.IsEnabled = false;
        UpdateButton.IsEnabled = false;
        HideSummary();
        HideError();
        ShowStatus("Đang chờ HoYo Launcher đóng hoàn toàn...");
        ProgressB.Visibility = Visibility.Visible;
        ProgressB.IsIndeterminate = true;

        string packageDir = _packageDir;
        string launcherRel = _launcherExeRelativePath ?? "";

        try
        {
            await Task.Run(() => UpdateWorker(packageDir, launcherRel));
            await ShowSuccessAndRelaunch(launcherRel);
        }
        catch (Exception ex)
        {
            HideStatus();
            ProgressB.Visibility = Visibility.Collapsed;
            ShowError("Cập nhật thất bại: " + ex.Message + "\nThư mục launcher hiện tại vẫn được giữ nguyên an toàn.");
            UpdateButton.IsEnabled = true;
        }
        finally
        {
            _busy = false;
        }
    }

    /// <summary>Trọn vẹn quá trình thay thế thư mục — chạy trong luồng nền.</summary>
    private void UpdateWorker(string packageDir, string launcherRel)
    {
        // 0) Khóa an toàn: đường dẫn đích bắt buộc đúng tên "System" và nằm trong BaseDir
        string baseFull = Path.GetFullPath(BaseDir).TrimEnd('\\') + "\\";
        string targetFull = Path.GetFullPath(TargetDir);
        if (!string.Equals(Path.GetFileName(targetFull.TrimEnd('\\')), TargetFolderName, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Đường dẫn đích không đúng — hủy để bảo vệ dữ liệu.");
        if (!targetFull.StartsWith(baseFull, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Đường dẫn đích nằm ngoài thư mục chương trình — hủy để bảo vệ dữ liệu.");

        // 1) Chờ mọi tiến trình chạy từ trong thư mục launcher thoát hẳn (tối đa 20 giây)
        Dispatch(() => StatusText.Text = "Đang chờ HoYo Launcher đóng hoàn toàn...");
        for (int i = 0; i < 40; i++)
        {
            if (!IsAnyProcessRunningUnder(targetFull)) break;
            Thread.Sleep(500);
            if (i == 39 && IsAnyProcessRunningUnder(targetFull))
                throw new InvalidOperationException(
                    "HoYo Launcher vẫn đang chạy và không chịu thoát. Hãy đóng launcher rồi bấm «Tiến hành Update» lại.");
        }

        // 2) Đặt lại tên thư mục cũ thành bản sao lưu .bak_<thời gian> — nếu lỗi giữa chừng vẫn còn
        //    nguyên dữ liệu cũ để khôi phục, và các thư mục cùng cấp (3DMigoto, Data Mods...) không bị ảnh hưởng.
        //    Trước hết quét dọn các sao lưu ".bak_*" sót lại từ lần cập nhật bị gián đoạn trước đó.
        CleanupStaleBackups();
        string? backupDir = null;
        if (Directory.Exists(targetFull))
        {
            backupDir = GetUniqueBackupDir(targetFull, DateTime.Now);
            Dispatch(() => StatusText.Text = "Đang lưu bản sao lưu của launcher cũ...");
            MoveWithRetry(targetFull, backupDir);
        }

        // 3) Chuyển thư mục mới (đã giải nén + xác minh) vào vị trí
        Dispatch(() => StatusText.Text = "Đang cài đặt bản cập nhật mới...");
        try
        {
            MoveWithRetry(packageDir, targetFull);
        }
        catch
        {
            // Lỗi khi đưa bản mới vào: khôi phục ngay thư mục cũ từ sao lưu
            if (backupDir != null && Directory.Exists(backupDir) && !Directory.Exists(targetFull))
                MoveWithRetry(backupDir, targetFull);
            throw;
        }

        // 4) Cài thành công -> dọn bản sao lưu cũ và XOÁ NGAY mọi file tạm
        Dispatch(() => StatusText.Text = "Đang dọn dẹp...");
        if (backupDir != null)
            TryDeleteDirectory(backupDir, 5, 600);

        // Xoá thẳng thư mục giải nén + file .zip tải về. Trước đây chúng nằm ở %TEMP% nên bị bỏ
        // quên tới lần chạy kế tiếp; giờ nằm trong thư mục cài launcher nên để lại sẽ chiếm
        // hàng trăm MB vĩnh viễn trên chính ổ đĩa đang chứa game. Bước này chỉ chạy khi cập
        // nhật đã thành công, nên nếu hỏng thì dữ liệu giải nén vẫn còn để thử lại.
        TryDeleteDirectory(ExtractRoot, 5, 600);
        TryDeleteDirectory(DownloadDir, 3, 300);
    }

    /// <summary>Có tiến trình nào đang chạy bằng file nằm trong thư mục chỉ định không?</summary>
    private static bool IsAnyProcessRunningUnder(string dir)
    {
        string dirPrefix = Path.GetFullPath(dir).TrimEnd('\\') + "\\";
        foreach (Process p in Process.GetProcesses())
        {
            try
            {
                string? exe = p.MainModule?.FileName;
                if (exe != null &&
                    Path.GetFullPath(exe).StartsWith(dirPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            catch { /* tiến trình hệ thống / quyền cao hơn không đọc được — bỏ qua */ }
            finally { p.Dispose(); }
        }
        return false;
    }

    // =====================================================================
    //  HOÀN TẤT — hiện thông báo 3 giây, tự đóng, mở lại launcher
    // =====================================================================

    private async Task ShowSuccessAndRelaunch(string launcherRel)
    {
        HideStatus();
        ProgressB.Visibility = Visibility.Collapsed;
        SuccessOverlay.Visibility = Visibility.Visible;

        // Đúng 3 giây theo yêu cầu
        await Task.Delay(3000);

        // Mở lại HoYo Launcher từ bản vừa cập nhật (ưu tiên exe, dự phòng file .bat cũ)
        try
        {
            string? exe = null;
            if (launcherRel.Length > 0)
            {
                string candidate = Path.Combine(TargetDir, launcherRel);
                if (File.Exists(candidate)) exe = candidate;
            }
            if (exe == null)
                exe = SafeListFiles(TargetDir).FirstOrDefault(f =>
                          string.Equals(f.Name, LauncherExeName, StringComparison.OrdinalIgnoreCase))?.FullName;

            if (exe != null)
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = exe,
                    WorkingDirectory = Path.GetDirectoryName(exe)!,
                    UseShellExecute = true
                });
            }
            else
            {
                // Dự phòng: mở launcher bằng file .bat ở thư mục gốc. Nhận CẢ HAI tên vì bản
                // phát hành này đặt tên "HoYoLauncher.bat", còn cây nguồn cũ đặt "System.bat".
                foreach (string batName in LauncherBatNames)
                {
                    string bat = Path.Combine(BaseDir, batName);
                    if (!File.Exists(bat)) continue;
                    Process.Start(new ProcessStartInfo { FileName = bat, UseShellExecute = true });
                    break;
                }
            }
        }
        catch { /* dù mở lại launcher có lỗi cũng vẫn đóng trình cập nhật như bình thường */ }

        Application.Current.Shutdown();
    }

    // =====================================================================
    //  TIỆN ÍCH FILE / THƯ MỤC
    // =====================================================================

    /// <summary>Tìm thư mục theo tên (không phân biệt hoa thường), ưu tiên vị trí NÔNG nhất; tự
    /// bỏ qua các thư mục không có quyền đọc thay vì sập giữa chừng.</summary>
    private static DirectoryInfo? FindDirectoryByName(string root, string name)
    {
        DirectoryInfo? best = null;
        int bestDepth = int.MaxValue;
        var queue = new Queue<string>();
        queue.Enqueue(root);

        while (queue.Count > 0)
        {
            string current = queue.Dequeue();
            int depth = CountSeparators(current);
            if (depth >= bestDepth) continue; // sâu hơn kết quả đã có -> bỏ

            string[] subDirs;
            try { subDirs = Directory.GetDirectories(current); }
            catch { continue; }

            foreach (string sub in subDirs)
            {
                if (string.Equals(Path.GetFileName(sub), name, StringComparison.OrdinalIgnoreCase))
                {
                    best = new DirectoryInfo(sub);
                    bestDepth = depth + 1;
                }
                else
                {
                    queue.Enqueue(sub);
                }
            }
        }
        return best;
    }

    private static int CountSeparators(string path)
    {
        int n = 0;
        foreach (char c in path)
            if (c == '\\' || c == '/') n++;
        return n;
    }

    /// <summary>Liệt kê mọi file trong thư mục (đệ quy), bỏ qua thư mục lỗi quyền.</summary>
    private static List<FileInfo> SafeListFiles(string dir)
    {
        var result = new List<FileInfo>();
        if (!Directory.Exists(dir)) return result;

        var stack = new Stack<string>();
        stack.Push(dir);
        while (stack.Count > 0)
        {
            string current = stack.Pop();
            string[] files;
            try { files = Directory.GetFiles(current); }
            catch { files = Array.Empty<string>(); }
            foreach (string f in files)
            {
                try { result.Add(new FileInfo(f)); } catch { }
            }

            string[] subDirs;
            try { subDirs = Directory.GetDirectories(current); }
            catch { subDirs = Array.Empty<string>(); }
            foreach (string s in subDirs) stack.Push(s);
        }
        return result;
    }

    /// <summary>Tên sao lưu dạng ".bak_<thời gian>" và nếu trùng (2 lần cập nhật trong cùng 1 giây)
    /// thì nối thêm _2, _3... — chắc chắn không bao giờ đụng tên cũ.</summary>
    private static string GetUniqueBackupDir(string targetDir, DateTime now)
    {
        string stamp = now.ToString("yyyyMMdd_HHmmss");
        string candidate = targetDir + ".bak_" + stamp;
        int n = 2;
        while (Directory.Exists(candidate))
        {
            candidate = targetDir + ".bak_" + stamp + "_" + n;
            n++;
        }
        return candidate;
    }

    /// <summary>Dọn các bản sao lưu ".bak_" còn sót từ lần cập nhật bị gián đoạn.</summary>
    private void CleanupStaleBackups()
    {
        try
        {
            foreach (string d in Directory.EnumerateDirectories(BaseDir, TargetFolderName + ".bak_*"))
                TryDeleteDirectory(d, 2, 300);
        }
        catch { }
    }

    /// <summary>Dọn thư mục tạm còn sót từ lần cập nhật bị gián đoạn (app bị tắt đột ngột, mất
    /// điện, người dùng bấm đóng giữa chừng...). Chạy ngay khi mở trình cập nhật — trước khi
    /// người dùng kịp làm gì — để không để lại hàng trăm MB rác trong thư mục cài launcher.
    /// Cần thêm cho trường hợp: lần trước dở dang rồi máy mất điện, lần này bấm "Xác minh" thì
    /// <see cref="VerifyWorker"/> cũng tự xóa, nhưng nếu người dùng chỉ mở lên rồi đóng thì không.</summary>
    private void CleanupStaleTemp()
    {
        TryDeleteDirectory(ExtractRoot, 3, 300);
        TryDeleteDirectory(DownloadDir, 2, 200);
    }

    /// <summary>Đổi tên/di chuyển thư mục, thử lại vài lần để tránh lỗi file bị khóa ngắn hạn.</summary>
    private static void MoveWithRetry(string src, string dst)
    {
        Exception? last = null;
        for (int i = 0; i < 3; i++)
        {
            try
            {
                if (Directory.Exists(dst))
                    throw new IOException($"Thư mục đích đã tồn tại: {dst}");
                Directory.Move(src, dst);
                return;
            }
            catch (Exception ex)
            {
                last = ex;
                Thread.Sleep(500);
            }
        }
        throw last!;
    }

    /// <summary>Cố gắng xóa thư mục (thử nhiều lần); thất bại thì bỏ qua không đổ lỗi.</summary>
    private static void TryDeleteDirectory(string path, int attempts, int delayMs)
    {
        for (int i = 0; i < attempts; i++)
        {
            try
            {
                if (!Directory.Exists(path)) return;
                Directory.Delete(path, true);
                return;
            }
            catch
            {
                if (i < attempts - 1) Thread.Sleep(delayMs);
            }
        }
    }

    // =====================================================================
    //  TIỆN ÍCH GIAO DIỆN
    // =====================================================================

    private bool IsBusy() => _busy;

    private void Dispatch(Action action) => Dispatcher.Invoke(action);

    private void SetDropZoneHighlight(bool on)
    {
        DropZone.Background = on ? "#1A2334".ToBrush() : "#141820".ToBrush();
        DropZone.BorderBrush = on ? "#5B8DEF".ToBrush() : "#2A3242".ToBrush();
        DropZoneOutline.Stroke = on ? "#5B8DEF".ToBrush() : "#2A3242".ToBrush();
    }

    private void ShowStatus(string text)
    {
        StatusText.Visibility = Visibility.Visible;
        StatusText.Text = text;
    }

    private void HideStatus() => StatusText.Visibility = Visibility.Collapsed;

    private void ShowSummary(string text)
    {
        SummaryPanel.Visibility = Visibility.Visible;
        SummaryText.Text = text;
    }

    private void HideSummary() => SummaryPanel.Visibility = Visibility.Collapsed;

    private void ShowError(string text)
    {
        ErrorPanel.Visibility = Visibility.Visible;
        ErrorText.Text = text;
    }

    private void HideError() => ErrorPanel.Visibility = Visibility.Collapsed;
}

/// <summary>Tiện ích đổi mã màu hex thành brush cho việc đổi màu tại code-behind.</summary>
internal static class BrushExtensions
{
    public static System.Windows.Media.SolidColorBrush ToBrush(this string hex) =>
        (System.Windows.Media.SolidColorBrush)new System.Windows.Media.BrushConverter().ConvertFromString(hex);
}
