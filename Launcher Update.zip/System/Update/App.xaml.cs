using System.Windows;

namespace HoYoLauncherUpdate;

public partial class App : Application
{
}
